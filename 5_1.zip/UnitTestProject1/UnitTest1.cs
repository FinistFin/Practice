﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Data;
using Biblio; 

namespace UnitTestProject1
{
    [TestClass]
    public class DatabaseHelperTests
    {
        [TestInitialize]
        public void Setup()
        {
            DatabaseHelper.ConnectionString = "Server=WIN-SVRRSUSI8LL\\SQLEXPRESS02;Database=CarRepairShop;Trusted_Connection=True"; 
        }

        [TestMethod]
        public void AuthenticateUser_ValidCredentials_ReturnsUserIDAndType()
        {
            var dbHelper = new DatabaseHelper();
            (int userID, int userTypeID) result = dbHelper.AuthenticateUser("login1", "pass1");
            Assert.IsTrue(result.userID > 0, "User ID should be greater than 0 for a valid user.");
            Assert.IsTrue(result.userTypeID > 0, "User Type ID should be greater than 0 for a valid user.");
        }

        [TestMethod]
        public void AuthenticateUser_InvalidCredentials_ReturnsNegativeIDs()
        {
            var dbHelper = new DatabaseHelper();
            (int userID, int userTypeID) result = dbHelper.AuthenticateUser("invalid_user", "invalid_password");
            Assert.AreEqual(-1, result.userID, "User ID should be -1 for an invalid user.");
            Assert.AreEqual(-1, result.userTypeID, "User Type ID should be -1 for an invalid user.");
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void AuthenticateUser_NoConnectionString_ThrowsException()
        {
            DatabaseHelper.ConnectionString = null;
            var dbHelper = new DatabaseHelper();
            dbHelper.AuthenticateUser("test", "test");
        }


        [TestMethod]
        public void GetRequests_ValidUserID_ReturnsData()
        {
            var dbHelper = new DatabaseHelper();
            int validUserID = 6;
            DataTable requests = dbHelper.GetRequests(validUserID);
            Assert.IsNotNull(requests);
            Assert.IsTrue(requests.Rows.Count > 0, "Should be at least one row returned");
        }


        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void GetMechanicRequestCounts_NoConnectionString_ThrowsException()
        {
            DatabaseHelper.ConnectionString = null;
            var dbHelper = new DatabaseHelper();
            dbHelper.GetMechanicRequestCounts();
        }


    }
}