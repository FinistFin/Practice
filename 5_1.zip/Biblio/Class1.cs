﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace Biblio
{
    public class DatabaseHelper
    {
        public static string ConnectionString { get; set; }

        private SqlConnection GetConnection()
        {
            if (string.IsNullOrEmpty(ConnectionString))
            {
                throw new InvalidOperationException("Connection string must be set.");
            }
            return new SqlConnection(ConnectionString);
        }

        public (int userID, int userTypeID) AuthenticateUser(string login, string password)
        {
            try
            {
                using (var connection = GetConnection())
                {
                    using (var command = new SqlCommand("SELECT UserID, UserTypeID FROM Users WHERE (login = @Login) AND password = @Password", connection))
                    {
                        command.Parameters.AddWithValue("@Login", login);
                        command.Parameters.AddWithValue("@Password", password);

                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int userID = reader.GetInt32(0);
                                int userTypeID = reader.GetInt32(1);
                                return (userID, userTypeID);
                            }
                            else
                            {
                                return (-1, -1); 
                            }
                        }
                    }

                }
            }
            catch (InvalidOperationException ex)
            {
                throw new InvalidOperationException($"Connection string is missing: {ex.Message}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Error authenticating user: {ex.Message}");
            }
        }

        public DataTable GetRequests(int userID)
        {
            try
            {
                return ExecuteQuery("SELECT * FROM Requests WHERE clientID = @userID", new Dictionary<string, object>() { { "@userID", userID } });
            }
            catch (InvalidOperationException ex)
            {
                throw new InvalidOperationException($"Connection string is missing: {ex.Message}");
            }

        }


        public Dictionary<int, int> GetMechanicRequestCounts()
        {
            try
            {
                var mechanicCounts = new Dictionary<int, int>();

                using (var table = ExecuteQuery("SELECT mechanicID, COUNT(*) AS RequestCount FROM Requests WHERE mechanicID IS NOT NULL GROUP BY mechanicID"))
                {
                    foreach (DataRow row in table.Rows)
                    {
                        mechanicCounts.Add((int)row["mechanicID"], (int)row["RequestCount"]);
                    }
                }

                return mechanicCounts;
            }
            catch (InvalidOperationException ex)
            {
                throw new InvalidOperationException($"Connection string is missing: {ex.Message}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting mechanic request counts: {ex.Message}");
            }

        }

        public DataTable GetAllUsers()
        {
            try
            {
                return ExecuteQuery("SELECT userID, login, password, fio, userTypeID FROM Users");
            }
            catch (InvalidOperationException ex)
            {
                throw new InvalidOperationException($"Connection string is missing: {ex.Message}");
            }
        }

        public int InsertRequest(
            DateTime startDate,
            int carTypeID,
            string problemDescription,
            string requestStatus,
            int clientID
        )
        {
            try
            {
                return (int)ExecuteScalar(@"INSERT INTO Requests (startDate, carTypeID, problemDescription, requestStatus, clientID)
                                        VALUES (@startDate, @carTypeID, @problemDescription, @requestStatus, @clientID);
                                        SELECT SCOPE_IDENTITY();",
                   new Dictionary<string, object>()
                   {
                        {"@startDate", startDate},
                        {"@carTypeID", carTypeID},
                        {"@problemDescription", problemDescription},
                        {"@requestStatus", requestStatus},
                        {"@clientID", clientID}
                   });
            }
            catch (InvalidOperationException ex)
            {
                throw new InvalidOperationException($"Connection string is missing: {ex.Message}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Error inserting request: {ex.Message}");
            }
        }

        public bool UpdateRequest(int requestID, string requestStatus, DateTime? completionDate, int? mechanicID)
        {
            try
            {
                int rowsAffected = ExecuteNonQuery(@"UPDATE Requests SET requestStatus = @requestStatus, completionDate = @completionDate, mechanicID = @mechanicID WHERE requestID = @requestID",
                                        new Dictionary<string, object>()
                    {
                            {"@requestID", requestID},
                            {"@requestStatus", requestStatus},
                            {"@completionDate", completionDate},
                            {"@mechanicID", mechanicID}
                    });
                return rowsAffected > 0;
            }
            catch (InvalidOperationException ex)
            {
                throw new InvalidOperationException($"Connection string is missing: {ex.Message}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Error updating request: {ex.Message}");
            }
        }

        private DataTable ExecuteQuery(string sql, Dictionary<string, object> parameters = null)
        {
            try
            {
                using (var connection = GetConnection())
                {
                    using (var command = new SqlCommand(sql, connection))
                    {
                        if (parameters != null)
                        {
                            foreach (var parameter in parameters)
                            {
                                command.Parameters.AddWithValue(parameter.Key, parameter.Value);
                            }
                        }
                        var adapter = new SqlDataAdapter(command);
                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        return table;
                    }
                }
            }
            catch (InvalidOperationException ex)
            {
                throw new InvalidOperationException($"Connection string is missing: {ex.Message}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Error executing query: {ex.Message}");
            }
        }

        private object ExecuteScalar(string sql, Dictionary<string, object> parameters = null)
        {
            try
            {
                using (var connection = GetConnection())
                {
                    using (var command = new SqlCommand(sql, connection))
                    {
                        if (parameters != null)
                        {
                            foreach (var parameter in parameters)
                            {
                                command.Parameters.AddWithValue(parameter.Key, parameter.Value);
                            }
                        }
                        connection.Open();
                        return command.ExecuteScalar();
                    }
                }
            }
            catch (InvalidOperationException ex)
            {
                throw new InvalidOperationException($"Connection string is missing: {ex.Message}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Error executing scalar: {ex.Message}");
            }

        }
        private int ExecuteNonQuery(string sql, Dictionary<string, object> parameters = null)
        {
            try
            {
                using (var connection = GetConnection())
                {
                    using (var command = new SqlCommand(sql, connection))
                    {
                        if (parameters != null)
                        {
                            foreach (var parameter in parameters)
                            {
                                command.Parameters.AddWithValue(parameter.Key, parameter.Value);
                            }
                        }
                        connection.Open();
                        return command.ExecuteNonQuery();
                    }
                }
            }
            catch (InvalidOperationException ex)
            {
                throw new InvalidOperationException($"Connection string is missing: {ex.Message}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Error executing non-query: {ex.Message}");
            }

        }
    }
}