﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Reflection.Emit;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace _5_1
{
    public partial class Form3 : Form
    {
        private int _currentUserID;
        private string connectionString = "Server=WIN-SVRRSUSI8LL\\SQLEXPRESS02;Database=CarRepairShop;Trusted_Connection=True"; //Строка подключения к БД.
        private DataTable _requestsTable;
        private bool _isLoadingData = false;
        private int _clientId = -1;
        private string _clientFIO = "";


        public Form3(int currentUserID)
        {
            InitializeComponent();
            _currentUserID = currentUserID;
            LoadClientData();
            comboBoxStatus.Items.AddRange(new string[] { "В ожидании", "В процессе", "Завершено" });
            comboBoxStatus.Visible = false;
            button4.Visible = false;
            InitializeComboBoxDates();
            LoadRequests();
        }


        private void LoadClientData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT  fio,  userTypeID, userID  FROM Users WHERE  userID = @userID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@userID", _currentUserID);
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                _clientFIO = reader["fio"].ToString();
                                label1.Text = $"Механик: {_clientFIO}";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных клиента: {ex.Message}", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void InitializeComboBoxDates()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT DISTINCT CAST(startDate AS DATE) AS startDate FROM Requests WHERE mechanicID = @mechanicID ORDER BY startDate DESC";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@mechanicID", _currentUserID);
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            comboBox1.Items.Clear();
                            comboBox1.Items.Add("Все даты");
                            while (reader.Read())
                            {
                                if (reader["startDate"] != DBNull.Value)
                                {
                                    comboBox1.Items.Add(((DateTime)reader["startDate"]).ToShortDateString());
                                }
                            }
                            comboBox1.SelectedIndex = 0;

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки дат заявок: {ex.Message}", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadRequests()
        {
            _isLoadingData = true;
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT requestID, startDate, carTypeID, problemDescription, requestStatus, clientID, mechanicID, completionDate FROM Requests WHERE mechanicID = @mechanicID";

                    if (comboBox1.SelectedItem != null && comboBox1.SelectedItem.ToString() != "Все даты")
                    {
                        query += " AND CAST(startDate AS DATE) = @selectedDate";
                    }

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.SelectCommand.Parameters.AddWithValue("@mechanicID", _currentUserID);

                    if (comboBox1.SelectedItem != null && comboBox1.SelectedItem.ToString() != "Все даты")
                    {
                        DateTime selectedDate = DateTime.Parse(comboBox1.SelectedItem.ToString());
                        adapter.SelectCommand.Parameters.AddWithValue("@selectedDate", selectedDate.Date);
                    }
                    _requestsTable = new DataTable();
                    adapter.Fill(_requestsTable);
                    dataGridView1.DataSource = _requestsTable;
                }
                UpdateLabel2();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заявок: {ex.Message}", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                _isLoadingData = false;
            }
        }

        private void UpdateLabel2()
        {
            if (_requestsTable != null)
                label2.Text = $"Всего заявок: {_requestsTable.Rows.Count}";
            else
                label2.Text = "Всего заявок: 0";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Выход на главную форму
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Изменение статуса выбранной заявки
            if (dataGridView1.SelectedRows.Count > 0)
            {
                comboBoxStatus.Visible = true;
                button4.Visible = true;
                // Load current value into the combobox
                string currentStatus = (string)dataGridView1.SelectedRows[0].Cells["requestStatus"].Value;
                comboBoxStatus.SelectedItem = currentStatus;

            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите заявку для редактирования");
            }
        }
        private void buttonStatus_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                if (comboBoxStatus.SelectedItem == null)
                {
                    MessageBox.Show("Выберите статус заявки");
                    return;
                }
                string newStatus = comboBoxStatus.SelectedItem.ToString();
                int requestID = (int)dataGridView1.SelectedRows[0].Cells["requestID"].Value;
                DateTime? completionDate = null;
                if (newStatus == "Завершено")
                {
                    completionDate = DateTime.Now;
                }

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        string query = "UPDATE Requests SET requestStatus = @requestStatus, completionDate = @completionDate WHERE requestID = @requestID";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@requestID", requestID);
                            command.Parameters.AddWithValue("@requestStatus", newStatus);
                            command.Parameters.AddWithValue("@completionDate", completionDate == null ? (object)DBNull.Value : completionDate);
                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                LoadRequests(); //Reload after update
                                comboBoxStatus.Visible = false;
                                button4.Visible = false;
                                MessageBox.Show($"Статус заявки {requestID} обновлен.");
                            }
                            else
                            {
                                MessageBox.Show($"Не удалось обновить статус заявки {requestID}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка обновления статуса заявки: {ex.Message}", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }
            else
            {
                MessageBox.Show("Выберите заявку для редактирования");
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int userID = (int)dataGridView1.SelectedRows[0].Cells["mechanicID"].Value;
                int requestID = (int)dataGridView1.SelectedRows[0].Cells["requestID"].Value;
                Form8 form8 = new Form8(userID, requestID);
                form8.ShowDialog();
            }
            else
            {
                MessageBox.Show("Выберите заявку для добавления комментария.");
            }
        }
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (!_isLoadingData && dataGridView1.SelectedRows.Count > 0)
            {
                comboBoxStatus.Visible = false;
                button4.Visible = false;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadRequests();
        }
    }
}