﻿using _5_1;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace _5_1
{
    public partial class Form1 : Form
    {
        public string connectionString = @"Server=WIN-SVRRSUSI8LL\SQLEXPRESS02;Database=CarRepairShop;Trusted_Connection=True";
        private string text = String.Empty;
        private int _loginAttempts = 0;
        private Timer _blockTimer;
        private DateTime _blockEndTime;
        private bool _isBlocked = false;
        private const string logFilePath = "authorization.txt";
        private bool _captchaRequired = false;
        private List<(string, Form)> _userForms = new List<(string, Form)>(); // Тип пользователя и соответствующая форма

        public Form1()
        {
            InitializeComponent();
            InitializeCaptcha();
            if (!File.Exists(logFilePath))
            {
                File.Create(logFilePath).Close();
            }
            _userForms.Add(("client", new Form2(-1))); // Форма 2 для клиента, id -1 как заглушка
            _userForms.Add(("mechanic", new Form3(-1))); // Форма 3 для механика, id -1 как заглушка
            _userForms.Add(("admin", new Form4(-1))); // Форма 4 для менеджера, id -1 как заглушка
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            UpdateLoginAttemptsLabel();
        }
        private void InitializeCaptcha()
        {
            this.labelCaptcha.Visible = false;
            this.textBoxCaptcha.Visible = false;
            this.buttonCaptchaConfirm.Visible = false;
            this.pictureBox1.Visible = false;
        }
        private string GenerateCaptcha()
        {
            Random random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(0, 4)
                .Select(s => chars[random.Next(chars.Length)]).ToArray());
        }
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void UpdateLoginAttemptsLabel()
        {
            labelAttempts.Text = $"Попытки входа: {_loginAttempts}";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (_isBlocked)
            {
                MessageBox.Show($"Пожалуйста, подождите {(_blockEndTime - DateTime.Now).Minutes} минут и {(_blockEndTime - DateTime.Now).Seconds} секунд.", "Блокировка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string login = textBox1.Text.Trim();
            string password = textBox2.Text.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                SaveLoginAttempt(login, password, false);
                MessageBox.Show("Пожалуйста, введите логин и пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (!_captchaRequired)
                {
                    _captchaRequired = true;
                    ShowCaptcha();
                    StartBlockTimer();
                }
                return;
            }
            if (_captchaRequired)
            {
                if (string.IsNullOrEmpty(textBoxCaptcha.Text) || textBoxCaptcha.Text != text)
                {
                    SaveLoginAttempt(login, password, false);
                    MessageBox.Show("Неверный CAPTCHA.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    HandleFailedLogin();
                    ShowCaptcha();
                    return;
                }
                else
                {
                    pictureBox1.Visible = false;

                    textBoxCaptcha.Visible = false;
                    buttonCaptchaConfirm.Visible = false;
                    _captchaRequired = false;
                }
            }


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT UserID, UserTypeID FROM Users WHERE (login = @Login) AND password = @Password";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Login", login);
                    command.Parameters.AddWithValue("@Password", password);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            int userID = reader.GetInt32(0);
                            int userTypeID = reader.GetInt32(1);
                            SaveLoginAttempt(login, password, true);
                            switch (userTypeID)
                            {
                                case 1:
                                    ShowForm(new Form2(userID));
                                    break;
                                case 2:
                                    ShowForm(new Form3(userID));
                                    break;
                                case 3:
                                    ShowForm(new Form7(userID));
                                    break;
                                case 4:
                                    ShowForm(new Form4(userID));
                                    break;
                                default:
                                    MessageBox.Show("Неизвестный тип пользователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    break;
                            }
                            return;
                        }
                        else
                        {
                            SaveLoginAttempt(login, password, false);
                            _loginAttempts++;
                            UpdateLoginAttemptsLabel();
                            HandleFailedLogin();
                            if (!_captchaRequired)
                            {
                                _captchaRequired = true;
                                ShowCaptcha();
                                StartBlockTimer();
                            }
                        }
                    }

                }
                catch (SqlException ex)
                {
                    MessageBox.Show($"Произошла ошибка при подключении к БД: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла непредвиденная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void HandleFailedLogin()
        {
            if (_loginAttempts >= 2)
            {
                MessageBox.Show("Вы заблокированы системой", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                BlockFormFields();
                return;
            }
        }

        private void SaveLoginAttempt(string login, string password, bool success)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(logFilePath, true))
                {
                    string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    string outcome = success ? "Успешно" : "Неудачно";
                    writer.WriteLine($"{timestamp} - Логин: {login}, Пароль: {password}, Результат: {outcome}");
                }
            }
            catch (IOException ex)
            {
                MessageBox.Show($"Ошибка при записи в файл: {ex.Message}", "Ошибка записи", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void BlockFormFields()
        {
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            button1.Enabled = false;
            checkBoxShowPassword.Enabled = false;
            labelCaptcha.Visible = false;
            textBoxCaptcha.Visible = false;
            buttonCaptchaConfirm.Visible = false;
            pictureBox1.Visible = false;
        }
        private void StartBlockTimer()
        {
            _blockEndTime = DateTime.Now.AddMinutes(3);
            _blockTimer = new Timer();
            _blockTimer.Interval = 1000;
            _blockTimer.Tick += BlockTimer_Tick;
            _blockTimer.Start();
        }
        private void BlockTimer_Tick(object sender, EventArgs e)
        {
            if (DateTime.Now >= _blockEndTime)
            {
                _blockTimer.Stop();
                _blockTimer.Dispose();
                _isBlocked = false;
                MessageBox.Show("Блокировка снята. Теперь можно попытаться авторизоваться.", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void ShowCaptcha()
        {
            pictureBox1.Visible = true;
            pictureBox1.Image = CreateImage(100, 50);
            labelCaptcha.Visible = true;
            textBoxCaptcha.Visible = true;
            buttonCaptchaConfirm.Visible = true;
        }
        private void buttonCaptchaConfirm_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxCaptcha.Text) || textBoxCaptcha.Text != text)
            {
                MessageBox.Show("Неверный CAPTCHA.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ShowCaptcha(); // Просто генерируем новую капчу
                StartBlockTimer();
                return;
            }
            else
            {
                pictureBox1.Visible = false;
                labelCaptcha.Visible = false;
                textBoxCaptcha.Visible = false;
                buttonCaptchaConfirm.Visible = false;
            }
        }
        private void ShowForm(Form form)
        {
            this.Hide();
            form.ShowDialog();
            this.Close();
        }
        private void checkBoxShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShowPassword.Checked)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }
        }
        private Bitmap CreateImage(int Width, int Height)
        {
            Random rnd = new Random();
            //Создадим изображение
            Bitmap result = new Bitmap(Width, Height);
            //Добавим различные цвета
            Brush[] colors = { Brushes.Black,
                     Brushes.Red,
                     Brushes.RoyalBlue,
                    Brushes.Green };
            //Укажем где рисовать
            Graphics g = Graphics.FromImage((System.Drawing.Image)result);
            //Пусть фон картинки будет серым
            g.Clear(Color.Gray);
            //Сгенерируем текст
            text = String.Empty;
            string ALF = "1234567890QWERTYUIOPASDFGHJKLZXCVBNM";
            for (int i = 0; i < 4; ++i)
                text += ALF[rnd.Next(ALF.Length)];
            //Нарисуем сгенирируемый текст
            g.DrawString(text,
                      new Font("Arial", 18),
                      colors[rnd.Next(colors.Length)],
                       new PointF(0, 0));
            //Добавим немного помех
            /////Линии из углов
            g.DrawLine(Pens.Black,
                         new Point(0, 0),
                       new Point(Width - 1, Height - 1));
            g.DrawLine(Pens.Black,
                      new Point(0, Height - 1),
                    new Point(Width - 1, 0));
            ////Белые точки
            for (int i = 0; i < Width; ++i)
                for (int j = 0; j < Height; ++j)
                    if (rnd.Next() % 20 == 0)
                        result.SetPixel(i, j, Color.White);

            return result;
        }
    }
}