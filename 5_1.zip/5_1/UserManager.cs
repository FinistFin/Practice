﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5_1
{
    internal class UserManager
    {


        internal class User
        {
            public string Login { get; set; }
            public string Table { get; set; }

            public User(string login, string table)
            {
                this.Login = login;
                this.Table = table;
            }
        }
        public static User CurrentUser { get; private set; }

        public static void SetCurrentUser(string login, string userType)
        {
            CurrentUser = new User(login, userType);
        }

        // Метод для получения clientID на основе логина (или email)
        public static int GetClientID()
        {
            string connectionString = @"Server=WIN-SVRRSUSI8LL\SQLEXPRESS02;Database=CarRepairShop;Trusted_Connection=True";
            if (CurrentUser == null || string.IsNullOrEmpty(CurrentUser.Login))
            {
                throw new InvalidOperationException("Current user is not set.");
            }

            string query = "SELECT ClientID FROM Client WHERE Email = @Login OR Phone = @Login"; // Используем почту или номер
            using (SqlConnection connection = new SqlConnection(connectionString)) // Убедитесь, что connectionString определен
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Login", CurrentUser.Login); // Используем логин для поиска

                var result = command.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : -1; // Возвращаем -1, если клиент не найден
            }
        }
    }

    public class User
    {
    }
}
