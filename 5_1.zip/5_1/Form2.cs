﻿using _5_1;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection.Emit;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _5_1
{
    public partial class Form2 : Form
    {
        private int _currentUserID;
        private string connectionString = "Server=WIN-SVRRSUSI8LL\\SQLEXPRESS02;Database=CarRepairShop;Trusted_Connection=True"; //Строка подключения к БД.


        public Form2(int userID)
        {
            InitializeComponent();
            _currentUserID = userID;
        }

        private void Form2_Load(object sender, EventArgs e)
        { 
            LoadClientData();
            LoadRequests();
            LoadRequestDates();
            UpdateLabel2();
        }

        private void LoadClientData()
        {
            // Загрузка ФИО клиента и обновление Label1
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string sql = "SELECT fio FROM Users WHERE userID = @UserID";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", _currentUserID);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                label1.Text = reader["fio"].ToString();
                            }
                            else
                            {
                                MessageBox.Show($"LoadClientData: No user found for userID = {_currentUserID}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error in LoadClientData: {ex.Message}");
                }
            }
        }

        private void LoadRequests()
        {
            // Загрузка заявок клиента и обновление DataGrid1
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string sql = @"SELECT requestID, startDate, carTypeID, problemDescription, requestStatus, completionDate
                            FROM Requests
                            WHERE clientID = @UserID";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", _currentUserID);
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dataGridView1.DataSource = table;

                        if (table.Rows.Count == 0)
                        {
                            MessageBox.Show($"LoadRequests: No requests found for userID = {_currentUserID}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error in LoadRequests: {ex.Message}");
                }
            }
            dataGridView1.Columns["requestID"].HeaderText = "ID заявки";
            dataGridView1.Columns["startDate"].HeaderText = "Дата начала";
            dataGridView1.Columns["problemDescription"].HeaderText = "Описание проблемы";
            dataGridView1.Columns["requestStatus"].HeaderText = "Статус";
            dataGridView1.Columns["completionDate"].HeaderText = "Дата завершения";
        }

        private void LoadRequestDates()
        {
            // Загрузка уникальных дат для ComboBox1
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string sql = "SELECT DISTINCT startDate FROM Requests WHERE clientID = @UserID";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", _currentUserID);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            comboBox1.Items.Clear();
                            while (reader.Read())
                            {
                                comboBox1.Items.Add(reader["startDate"]);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error in LoadRequestDates: {ex.Message}");
                }

            }
        }

        private void UpdateLabel2()
        {
            // Обновление Label2 (Количество заявок)
            label2.Text = $"Количество заявок: {dataGridView1.Rows.Count - 1}";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Фильтрация заявок по выбранной дате
            if (comboBox1.SelectedItem != null)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = @"SELECT requestID, startDate, carTypeID, problemDescription, requestStatus, completionDate
                                FROM Requests
                                WHERE clientID = @UserID AND startDate = @SelectedDate";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", _currentUserID);
                        command.Parameters.AddWithValue("@SelectedDate", Convert.ToDateTime(comboBox1.SelectedItem));
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dataGridView2.DataSource = table;
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Открытие формы 5 (создание заявки)
            Form5 form5 = new Form5(_currentUserID); // передача userID
            form5.ShowDialog();
            LoadRequests();
            LoadRequestDates();
            UpdateLabel2();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Удаление выбранной заявки
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int requestID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["requestID"].Value);
                DialogResult result = MessageBox.Show("Вы уверены, что хотите удалить эту заявку?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string sql = "DELETE FROM Requests WHERE requestID = @RequestID";
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {
                            command.Parameters.AddWithValue("@RequestID", requestID);
                            command.ExecuteNonQuery();
                        }
                    }
                    LoadRequests();
                    LoadRequestDates();
                    UpdateLabel2();
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста выберите заявку для удаления.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Изменение выбранной заявки
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int requestID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["requestID"].Value);
                Form6 form6 = new Form6(_currentUserID, requestID);
                form6.ShowDialog();
                LoadRequests();
                LoadRequestDates();
                UpdateLabel2();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите заявку для редактирования");
            }
        }
    }
}