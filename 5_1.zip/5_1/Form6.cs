﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection.Emit;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _5_1
{
    public partial class Form6 : Form
    {
        private int _userID;
        private int _requestID;
        string connectionString = @"Server=WIN-SVRRSUSI8LL\SQLEXPRESS02;Database=CarRepairShop;Trusted_Connection=True";

        public Form6(int userID, int requestID)
        {
            InitializeComponent();
            _userID = userID;
            _requestID = requestID;
            LoadCarTypes();
            LoadRequestDetails();

        }
        // Метод для загрузки ФИО клиента
        private void LoadClientFIO()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT FIO FROM Users WHERE UserID = @UserID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserID", _userID);

                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        label2.Text = $"ФИО клиента: {result.ToString()}";
                    }
                    else
                    {
                        label2.Text = "ФИО клиента не найдено";
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Ошибка при загрузке ФИО клиента: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Непредвиденная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        // Метод для загрузки типов автомобилей в ComboBox
        private void LoadCarTypes()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT carTypeID, carType, carModel FROM CarTypes";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable carTypesTable = new DataTable();
                    adapter.Fill(carTypesTable);

                    comboBox1.DisplayMember = "carType";
                    comboBox1.ValueMember = "carTypeID";
                    comboBox1.DataSource = carTypesTable;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Ошибка при загрузке типов автомобилей: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Непредвиденная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Метод для загрузки деталей заявки
        private void LoadRequestDetails()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT carTypeID, problemDescription FROM Requests WHERE requestID = @requestID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@requestID", _requestID);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            int carTypeID = reader.GetInt32(0);
                            string problemDescription = reader.GetString(1);

                            // Выбор типа автомобиля
                            comboBox1.SelectedValue = carTypeID;
                            textBox1.Text = problemDescription;
                        }
                        else
                        {
                            MessageBox.Show("Заявка не найдена", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            this.Close();
                        }
                    }

                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных заявки: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Непредвиденная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Обработчик для кнопки сохранения изменений
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.SelectedItem == null || string.IsNullOrEmpty(textBox1.Text))
                {
                    MessageBox.Show("Пожалуйста, выберите тип автомобиля и опишите поломку.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int carTypeID = Convert.ToInt32(comboBox1.SelectedValue);
                string problemDescription = textBox1.Text.Trim();
                DateTime startDate = DateTime.Now;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE Requests SET startDate = @startDate, carTypeID = @carTypeID, problemDescription = @problemDescription WHERE requestID = @requestID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@startDate", startDate.Date);
                    command.Parameters.AddWithValue("@carTypeID", carTypeID);
                    command.Parameters.AddWithValue("@problemDescription", problemDescription);
                    command.Parameters.AddWithValue("@requestID", _requestID);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Заявка успешно изменена!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Ошибка при изменении заявки: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Непредвиденная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
