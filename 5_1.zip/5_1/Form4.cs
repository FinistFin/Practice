﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection.Emit;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _5_1
{
    public partial class Form4 : Form
    {
        private string connectionString = "Server=WIN-SVRRSUSI8LL\\SQLEXPRESS02;Database=CarRepairShop;Trusted_Connection=True"; //Строка подключения к БД.
        private int _currentUserID;
        private int selectedMechanicID = -1;
        private DataTable _allRequestsTable;

        public Form4(int userID)
        {
            InitializeComponent();
            _currentUserID = userID;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            LoadAllRequests();
            LoadRequestIDs();
            LoadRequestDates();
            UpdateLabel2();
            LoadMechanicList();
        }

        private void LoadAllRequests()
        {
            // Загрузка всех заявок
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string sql = "SELECT requestID, startDate, carTypeID, problemDescription, requestStatus, completionDate, clientID, mechanicID FROM Requests";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        _allRequestsTable = new DataTable();
                        adapter.Fill(_allRequestsTable);
                        dataGridView1.DataSource = _allRequestsTable;

                        // Настройка заголовков таблицы
                        dataGridView1.Columns["requestID"].HeaderText = "ID заявки";
                        dataGridView1.Columns["startDate"].HeaderText = "Дата начала";
                        dataGridView1.Columns["problemDescription"].HeaderText = "Описание проблемы";
                        dataGridView1.Columns["requestStatus"].HeaderText = "Статус";
                        dataGridView1.Columns["completionDate"].HeaderText = "Дата завершения";
                        dataGridView1.Columns["clientID"].HeaderText = "ID клиента";
                        dataGridView1.Columns["mechanicID"].HeaderText = "ID механика";
                        if (_allRequestsTable.Rows.Count == 0)
                        {
                            MessageBox.Show("No requests found!");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error in LoadAllRequests: {ex.Message}");
                }
            }
        }

        private void UpdateLabel2()
        {
            // Обновление Label2 (Количество заявок)
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string sql = "SELECT COUNT(*) FROM Requests";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        int count = (int)command.ExecuteScalar();
                        label2.Text = "Количество заявок: " + count.ToString();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error in UpdateLabel2: {ex.Message}");
                }

            }
        }


        private void LoadRequestIDs()
        {
            // Загрузка уникальных requestID для ComboBox1
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string sql = "SELECT requestID FROM Requests";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            comboBox1.Items.Clear();
                            while (reader.Read())
                            {
                                comboBox1.Items.Add(reader["requestID"]);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error in LoadRequestIDs: {ex.Message}");
                }

            }
        }

        private void LoadRequestDates()
        {
            // Загрузка уникальных дат для ComboBox2
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string sql = "SELECT DISTINCT startDate FROM Requests";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            comboBox2.Items.Clear();
                            while (reader.Read())
                            {
                                comboBox2.Items.Add(reader["startDate"]);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error in LoadRequestDates: {ex.Message}");
                }

            }
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Фильтрация заявок по выбранному requestID
            if (comboBox1.SelectedItem != null)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        string sql = @"SELECT requestID, startDate, carTypeID, problemDescription, requestStatus, completionDate, clientID, mechanicID
								FROM Requests
								WHERE requestID = @RequestID";
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {
                            command.Parameters.AddWithValue("@RequestID", Convert.ToInt32(comboBox1.SelectedItem));
                            SqlDataAdapter adapter = new SqlDataAdapter(command);
                            DataTable table = new DataTable();
                            adapter.Fill(table);
                            dataGridView2.DataSource = table;
                            // Настройка заголовков таблицы
                            dataGridView2.Columns["requestID"].HeaderText = "ID заявки";
                            dataGridView2.Columns["startDate"].HeaderText = "Дата начала";
                            dataGridView2.Columns["problemDescription"].HeaderText = "Описание проблемы";
                            dataGridView2.Columns["requestStatus"].HeaderText = "Статус";
                            dataGridView2.Columns["completionDate"].HeaderText = "Дата завершения";
                            dataGridView2.Columns["clientID"].HeaderText = "ID клиента";
                            dataGridView2.Columns["mechanicID"].HeaderText = "ID механика";
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error in comboBox1_SelectedIndexChanged: {ex.Message}");
                    }

                }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Фильтрация заявок по выбранной дате
            if (comboBox2.SelectedItem != null)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        string sql = @"SELECT requestID, startDate, carTypeID, problemDescription, requestStatus, completionDate, clientID, mechanicID
								FROM Requests
								WHERE startDate = @SelectedDate";
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {
                            command.Parameters.AddWithValue("@SelectedDate", Convert.ToDateTime(comboBox2.SelectedItem));
                            SqlDataAdapter adapter = new SqlDataAdapter(command);
                            DataTable table = new DataTable();
                            adapter.Fill(table);
                            dataGridView3.DataSource = table;
                            // Настройка заголовков таблицы
                            dataGridView3.Columns["requestID"].HeaderText = "ID заявки";
                            dataGridView3.Columns["startDate"].HeaderText = "Дата начала";
                            dataGridView3.Columns["problemDescription"].HeaderText = "Описание проблемы";
                            dataGridView3.Columns["requestStatus"].HeaderText = "Статус";
                            dataGridView3.Columns["completionDate"].HeaderText = "Дата завершения";
                            dataGridView3.Columns["clientID"].HeaderText = "ID клиента";
                            dataGridView3.Columns["mechanicID"].HeaderText = "ID механика";
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error in comboBox2_SelectedIndexChanged: {ex.Message}");
                    }

                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите заявку для назначения механика.");
                return;
            }

            int requestID = (int)dataGridView1.SelectedRows[0].Cells["requestID"].Value;

            if (comboBoxMechanic.SelectedItem != null)
            {
                selectedMechanicID = (int)((dynamic)comboBoxMechanic.SelectedItem).userID;
            }
            else
            {
                selectedMechanicID = -1; // Значение "не назначено"
            }


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string sql = "";

                    if (selectedMechanicID == -1)
                    {
                        sql = "UPDATE Requests SET mechanicID = NULL WHERE requestID = @requestID";
                    }
                    else
                    {
                        sql = "UPDATE Requests SET mechanicID = @mechanicID WHERE requestID = @requestID";
                    }

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        if (selectedMechanicID != -1)
                        {
                            command.Parameters.AddWithValue("@mechanicID", selectedMechanicID);
                        }

                        command.Parameters.AddWithValue("@requestID", requestID);
                        command.ExecuteNonQuery();
                    }
                    MessageBox.Show("Механик успешно назначен.");
                    LoadAllRequests();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show($"Ошибка при назначении механика: {ex.Message}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла ошибка: {ex.Message}");
                }
            }
        }

        private void LoadMechanicList()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string sql = "SELECT userID, fio FROM Users WHERE userTypeID = 2";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            comboBoxMechanic.DataSource = null; //Очищаем список
                            comboBoxMechanic.Items.Clear();
                            comboBoxMechanic.DisplayMember = "fio";
                            comboBoxMechanic.ValueMember = "userID";
                            comboBoxMechanic.Items.Add(new { fio = "Не назначено", userID = -1 });
                            while (reader.Read())
                            {
                                comboBoxMechanic.Items.Add(new { fio = reader["fio"].ToString(), userID = Convert.ToInt32(reader["userID"]) });
                            }

                            comboBoxMechanic.DisplayMember = "fio";
                            comboBoxMechanic.ValueMember = "userID";
                            comboBoxMechanic.DataSource = comboBoxMechanic.Items;
                        }
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show($"Ошибка при загрузке списка механиков: {ex.Message}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла ошибка: {ex.Message}");
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (_allRequestsTable == null)
            {
                return;
            }

            string filterText = textBox1.Text.Trim();
            if (string.IsNullOrEmpty(filterText))
            {
                dataGridView1.DataSource = _allRequestsTable;
            }
            else
            {
                DataView dv = _allRequestsTable.DefaultView;
                dv.RowFilter = string.Format("problemDescription LIKE '%{0}%'", filterText);
                dataGridView1.DataSource = dv.ToTable();
            }

        }
    }
}