﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection.Emit;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _5_1 
{
    public partial class Form5 : Form
    {
        private int _userID;
        string connectionString = @"Server=WIN-SVRRSUSI8LL\SQLEXPRESS02;Database=CarRepairShop;Trusted_Connection=True";

        public Form5(int userID)
        {
            InitializeComponent();
            _userID = userID;
            LoadCarTypes();
            LoadClientFIO();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            UpdateLabel3();
        }

        // Метод для загрузки типов и моделей автомобилей в ComboBox
        private void LoadCarTypes()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT carTypeID, carType, carModel FROM CarTypes";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable carTypesTable = new DataTable();
                    adapter.Fill(carTypesTable);

                    comboBox1.DisplayMember = "carType";
                    comboBox1.ValueMember = "carTypeID";
                    comboBox1.DataSource = carTypesTable;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Ошибка при загрузке типов автомобилей: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Непредвиденная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Метод для загрузки ФИО клиента
        private void LoadClientFIO()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT FIO FROM Users WHERE UserID = @UserID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserID", _userID);

                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        label2.Text = $"ФИО клиента: {result.ToString()}";
                    }
                    else
                    {
                        label2.Text = "ФИО клиента не найдено";
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Ошибка при загрузке ФИО клиента: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Непредвиденная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Метод для обновления label3
        private void UpdateLabel3()
        {
            label3.Text = $"Текущая дата: {DateTime.Now.ToShortDateString()}";
        }

        // Обработчик для кнопки сохранения заявки
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.SelectedItem == null || string.IsNullOrEmpty(textBox1.Text))
                {
                    MessageBox.Show("Пожалуйста, выберите тип автомобиля и опишите поломку.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // получаем carTypeID из выбранного элемента
                int carTypeID = Convert.ToInt32(comboBox1.SelectedValue);
                string problemDescription = textBox1.Text.Trim();
                string requestStatus = "Новая заявка"; // Статус новой заявки
                DateTime startDate = DateTime.Now; // Текущая дата

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Requests (startDate, carTypeID, problemDescription, requestStatus, userID) " +
                                "VALUES (@startDate, @carTypeID, @problemDescription, @requestStatus, @userID)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@startDate", startDate.Date);
                    command.Parameters.AddWithValue("@carTypeID", carTypeID);
                    command.Parameters.AddWithValue("@problemDescription", problemDescription);
                    command.Parameters.AddWithValue("@requestStatus", requestStatus);
                    command.Parameters.AddWithValue("@userID", _userID);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Заявка успешно сохранена!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Ошибка при сохранении заявки: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Непредвиденная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
