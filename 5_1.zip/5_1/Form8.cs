﻿using System;
using System.Data.SqlClient;
using System.Reflection.Emit;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _5_1
{
    public partial class Form8 : Form
    {
        private int _userID;
        private int _requestID;
        string connectionString = @"Server=WIN-SVRRSUSI8LL\SQLEXPRESS02;Database=CarRepairShop;Trusted_Connection=True";

        public Form8(int userID, int requestID)
        {
            InitializeComponent();
            _userID = userID;
            _requestID = requestID;
            LoadMechanicFIO();
        }
        // Загрузка ФИО автомеханика
        private void LoadMechanicFIO()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT FIO FROM Users WHERE UserID = @UserID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserID", _userID);
                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        label1.Text = $"ФИО: {result.ToString()}";
                    }
                    else
                    {
                        label1.Text = "ФИО не найдено";
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Ошибка при загрузке ФИО: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Непредвиденная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Обработчик для кнопки сохранения комментария
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textBox1.Text))
                {
                    MessageBox.Show("Пожалуйста, введите комментарий", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                string comment = textBox1.Text.Trim();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Comments (message, userID, requestID) VALUES (@message, @userID, @requestID)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@message", comment);
                    command.Parameters.AddWithValue("@userID", _userID);
                    command.Parameters.AddWithValue("@requestID", _requestID);
                    command.ExecuteNonQuery();

                    MessageBox.Show("Комментарий успешно сохранен!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Ошибка при сохранении комментария: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Непредвиденная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}