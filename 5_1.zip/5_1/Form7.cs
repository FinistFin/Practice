﻿using QRCoder;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace _5_1
{
    public partial class Form7 : Form
    {
        public string connectionString = @"Server=WIN-SVRRSUSI8LL\SQLEXPRESS02;Database=CarRepairShop;Trusted_Connection=True";
        private int _userId;
        private DataTable _requestsTable;
        private Dictionary<int, string> _mechanics;

        public Form7(int userId)
        {
            InitializeComponent();
            _userId = userId;
            label1.Text = $"Менеджер по качеству, UserID = {userId}";
            LoadRequests();
            LoadMechanics();
        }

        private void GenerateQRCode()
        {
            string googleSheetUrl = "https://docs.google.com/spreadsheets/d/1WfPVTqLY6EKSZhXll9o9mZR0kYYH_EiYkf7yceugJ4E/edit?gid=274168655"; // Your OpenAI Sheet URL

            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(googleSheetUrl, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);

            pictureBox1.Image = qrCodeImage;
            pictureBox1.Visible = true;
        }

        private void LoadRequests()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT requestID, startDate, carTypeID, problemDescription, requestStatus, clientID, mechanicID FROM Requests";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    _requestsTable = new DataTable();
                    adapter.Fill(_requestsTable);
                    dataGridView1.DataSource = _requestsTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заявок: {ex.Message}", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadMechanics()
        {
            try
            {
                _mechanics = new Dictionary<int, string>();
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT userID, fio FROM Users WHERE userTypeID = 2";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                _mechanics.Add((int)reader["userID"], (string)reader["fio"]);
                            }
                        }
                    }
                }
                comboBox1.DataSource = new BindingSource(_mechanics, null);
                comboBox1.DisplayMember = "Value";
                comboBox1.ValueMember = "Key";

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки механиков: {ex.Message}", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            GenerateQRCode();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0 && comboBox1.SelectedValue != null)
            {
                int requestID = (int)dataGridView1.SelectedRows[0].Cells["requestID"].Value;
                int mechanicID = (int)comboBox1.SelectedValue;
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        string query = "UPDATE Requests SET requestStatus = @requestStatus, completionDate = @completionDate, mechanicID = @mechanicID WHERE requestID = @requestID";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@requestID", requestID);
                            command.Parameters.AddWithValue("@requestStatus", "In Progress");
                            command.Parameters.AddWithValue("@completionDate", DBNull.Value);
                            command.Parameters.AddWithValue("@mechanicID", mechanicID);
                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                LoadRequests(); 
                                MessageBox.Show($"Механик назначен к заявке {requestID}");
                            }
                            else
                            {
                                MessageBox.Show($"Не удалось назначить механика к заявке {requestID}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка назначения механика: {ex.Message}", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Выберите заявку и механика");
            }
        }
    }
}
